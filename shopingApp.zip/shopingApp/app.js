const express = require('express');

const app = express();

// Create an array to store the shopping list items
const shoppingList = [];

// Define a route for the home page
app.get('/', (req, res) => {
  res.send('Hello, world!');
});

// Define a route to get all of the shopping list items
app.get('/items', (req, res) => {
  res.send(shoppingList);
});

// Define a route to add a new item to the shopping list
app.post('/items', (req, res) => {
  const newItem = {
    name: req.body.name,
    price: req.body.price,
  };

  shoppingList.push(newItem);

  res.send('Item added to shopping list');
});

// Define a route to get a single shopping list item
app.get('/items/:id', (req, res) => {
  const id = req.params.id;
  const item = shoppingList[id];

  res.send(item);
});

// Define a route to edit a shopping list item
app.patch('/items/:id', (req, res) => {
  const id = req.params.id;
  const item = shoppingList[id];

  item.name = req.body.name;
  item.price = req.body.price;

  res.send('Item updated');
});

// Define a route to delete a shopping list item
app.delete('/items/:id', (req, res) => {
  const id = req.params.id;
  shoppingList.splice(id, 1);

  res.send('Item deleted');
});

// Start the Express.js server
app.listen(3000, () => {
  console.log('Server listening on port 3000');
});
